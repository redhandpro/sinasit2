document.addEventListener('DOMContentLoaded', () => {
  console.log('Sina Sit Developer site loaded ✅');
});